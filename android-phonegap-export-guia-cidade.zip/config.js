define( function ( require ) {

	"use strict";

	return {
		app_slug : 'guia-cidade',
		wp_ws_url : 'http://suamoradia.israelwilson.com.br/app/wp-appkit-api/guia-cidade',
		wp_url : 'http://suamoradia.israelwilson.com.br/app',
		theme : 'q-android',
		version : '0.1',
		app_title : 'GC Top BAR',
		app_platform : 'android',
		gmt_offset : -3,
		debug_mode : 'off',
		auth_key : '1l%M+9[Xo*sMmhbfU2#;f@%Az+Z T/Q[1/ADwP^An07pU`OA1CLR0jZ3gtAHfFaL',
		options : {"refresh_interval":0},
		theme_settings : [],
		addons : []
	};

});
